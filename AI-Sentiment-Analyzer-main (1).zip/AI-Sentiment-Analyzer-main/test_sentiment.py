"""
Test script for sentiment analysis functionality
"""

from textblob import TextBlob

def test_sentiment_analysis():
    """Test sentiment analysis with sample texts"""
    
    test_cases = [
        "I love this application! It's amazing!",
        "This is terrible and I hate it.",
        "The weather is okay today.",
        "Python is a programming language.",
        "I'm so excited about this project!"
    ]
    
    print("Testing Sentiment Analysis:")
    print("=" * 50)
    
    for text in test_cases:
        blob = TextBlob(text)
        polarity = blob.sentiment.polarity
        subjectivity = blob.sentiment.subjectivity
        
        if polarity > 0.1:
            sentiment = "Positive"
        elif polarity < -0.1:
            sentiment = "Negative"
        else:
            sentiment = "Neutral"
        
        print(f"\nText: {text}")
        print(f"Sentiment: {sentiment}")
        print(f"Polarity: {polarity:.3f}")
        print(f"Subjectivity: {subjectivity:.3f}")
        print("-" * 30)

if __name__ == "__main__":
    try:
        test_sentiment_analysis()
    except ImportError:
        print("TextBlob not installed. Run 'pip install textblob' first.")
    except Exception as e:
        print(f"Error: {e}")
        print("You may need to download NLTK data. Run:")
        print("python -c \"import nltk; nltk.download('punkt'); nltk.download('brown')\"")