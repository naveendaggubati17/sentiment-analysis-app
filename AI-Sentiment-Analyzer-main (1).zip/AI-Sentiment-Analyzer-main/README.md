# Sentiment Analysis Web Application

A Flask-based web application that performs sentiment analysis on user-entered text using TextBlob. The application classifies text as positive, negative, or neutral and displays polarity and subjectivity scores.

## Features

- **Real-time Sentiment Analysis**: Analyze text sentiment instantly
- **Polarity Score**: Ranges from -1 (very negative) to +1 (very positive)
- **Subjectivity Score**: Ranges from 0 (objective) to 1 (subjective)
- **Visual Results**: Color-coded sentiment badges and progress bars
- **Responsive Design**: Works on desktop and mobile devices
- **REST API**: JSON API endpoint for programmatic access

## Installation

1. **Clone or download the project**
2. **Run the setup script**:
   ```bash
   setup.bat
   ```
   
   Or manually install:
   ```bash
   pip install -r requirements.txt
   python -c "import nltk; nltk.download('punkt'); nltk.download('brown')"
   ```

## Usage

1. **Start the application**:
   ```bash
   python app.py
   ```

2. **Open your browser** and go to: `http://127.0.0.1:5000`

3. **Enter text** in the textarea and click "Analyze Sentiment"

4. **View results** including:
   - Sentiment classification (Positive/Negative/Neutral)
   - Polarity score with visual bar
   - Subjectivity score with visual bar

## API Usage

Send POST requests to `/api/analyze` with JSON data:

```bash
curl -X POST http://127.0.0.1:5000/api/analyze \
  -H "Content-Type: application/json" \
  -d '{"text": "I love this application!"}'
```

Response:
```json
{
  "sentiment": "Positive",
  "polarity": 0.625,
  "subjectivity": 0.6
}
```

## Project Structure

```
sentiment_analysis_app/
├── app.py                 # Main Flask application
├── requirements.txt       # Python dependencies
├── setup.bat             # Setup script
├── README.md             # This file
├── templates/
│   └── index.html        # Main HTML template
└── static/
    └── css/
        └── style.css     # CSS styles
```

## Understanding the Scores

### Polarity
- **Range**: -1.0 to +1.0
- **-1.0**: Very negative sentiment
- **0.0**: Neutral sentiment
- **+1.0**: Very positive sentiment

### Subjectivity
- **Range**: 0.0 to 1.0
- **0.0**: Objective (factual information)
- **1.0**: Subjective (personal opinion/emotion)

## Dependencies

- **Flask**: Web framework
- **TextBlob**: Natural language processing library
- **Werkzeug**: WSGI utility library

## Browser Compatibility

- Chrome (recommended)
- Firefox
- Safari
- Edge

## Troubleshooting

1. **Import Error**: Run `setup.bat` to install dependencies
2. **NLTK Data Error**: Download required corpora:
   ```python
   import nltk
   nltk.download('punkt')
   nltk.download('brown')
   ```
3. **Port Already in Use**: Change port in `app.py` or stop other applications using port 5000

## License

This project is open source and available under the MIT License.